public class InventoryItem {
    private String name;
    private int units;
    private float price;

    public InventoryItem(String name, int units, float price) {
        this.name = name;
        this.units = units;
        this.price = price;
    }

    public void restock(int additionalUnits) {
        this.units += additionalUnits;
    }

    public String getName() {
        return name;
    }

    public int getUnits() {
        return units;
    }

    public float getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return name + " " + units + " " + price;
    }
}