import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.StringTokenizer;

public class BufferedReader2 {

    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String line;

        System.out.println("Enter lines of text (type 'quit' to exit):");

        try {
            while ((line = reader.readLine()) != null) {
                if (line.equals("quit")) {
                    break;
                }

                // StringTokenizer 객체 생성 및 초기화
                StringTokenizer tokenizer = new StringTokenizer(line);

                // 단어의 수 출력
                int wordCount = tokenizer.countTokens();
                System.out.println("There are " + wordCount + " words in this line.");

                // 각 단어를 한 줄씩 출력
                while (tokenizer.hasMoreTokens()) {
                    System.out.println(tokenizer.nextToken());
                }
            }
        } catch (IOException e) {
            System.out.println("IOException occurred: " + e.getMessage());
        } finally {
            try {
                reader.close();
            } catch (IOException e) {
                System.out.println("Error closing the reader: " + e.getMessage());
            }
        }
    }
}
