public class MathUtils {
    //-------------------------------------------------------------
    // Returns the factorial of the argument given
    // Throws IllegalArgumentException if the argument is negative
    // or greater than or equal to 17
    //-------------------------------------------------------------
    public static int factorial(int n) throws IllegalArgumentException {
        if (n < 0) {
            throw new IllegalArgumentException("Factorial is not defined for negative numbers.");
        } else if (n >= 17) {
            throw new IllegalArgumentException("Factorial for numbers 17 or higher is too large to compute.");
        }
        
        int fac = 1;
        for (int i = n; i > 0; i--) {
            fac *= i;
        }
        return fac;
    }
}
